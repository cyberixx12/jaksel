## How to contribute

Just contribute, This project just for fun

- Create issue, it could be bug, feature, suggeset, etc.
- Create solution if any
- Create pull request if you are a nice person
